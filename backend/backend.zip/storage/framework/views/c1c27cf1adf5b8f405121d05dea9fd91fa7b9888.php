

<?php $__env->startSection('title', 'バイク・車好きのためのウェブアプリ'); ?>
<?php $__env->startSection('description', 'バイク・車好きのためのウェブアプリ「モタサポ」の公式アプリです。'); ?>
<?php $__env->startSection('pageCss'); ?>
<?php $__env->startSection('h1', 'モタサポ'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('js/components/InputAnimation.js')); ?>"></script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

<div class="page-headline page-content">
    <p>
        <?php if(Request::is('register-user')): ?>
        ユーザー情報を
        <?php elseif(Request::is('register-shop')): ?>
        ショップ情報を
        <?php endif; ?>
        <br>入力してください。
    </p>
</div>

<div class="page-content">
    <?php if(Request::is('register-user')): ?>
    <form method="POST" action="<?php echo e(route('register.user')); ?>">
    <?php elseif(Request::is('register-shop')): ?>
    <form method="POST" action="<?php echo e(route('register.shop')); ?>">
    <?php endif; ?>
    
    
        <?php echo csrf_field(); ?>
        <ul class="c-lists">
            <li class="c-list c-input">
                <label
                    for="name"
                    class="c-input__label"
                >
                    アカウント名(半角英数字のみ)
                </label>
                <input
                    name="account"
                    id="account"
                    type="text"
                    class="<?php $__errorArgs = ['account'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> c-input__target"
                    value="<?php echo e(old('account')); ?>"
                    required
                />
                <?php $__errorArgs = ['account'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="l-alert__text--red"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </li>
            <li class="c-list c-input">
                <label
                    for="name"
                    class="c-input__label"
                >
                    <?php if(Request::is('register-user')): ?>
                    お名前
                    <?php elseif(Request::is('register-shop')): ?>
                    ショップ名
                    <?php endif; ?>
                </label>
                <input
                    name="name"
                    id="name"
                    type="text"
                    class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> c-input__target"
                    value="<?php echo e(old('name')); ?>"
                    required
                />
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="l-alert__text--red"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </li>
            <li class="c-list c-input">
                <label
                    for="email"
                    class="c-input__label"
                >
                    メールアドレス
                </label>
                <input
                    name="email"
                    id="email"
                    type="email"
                    class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> c-input__target"
                    value="<?php echo e(old('email')); ?>"
                    required
                />
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="l-alert__text--red"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </li>
            <li class="c-list c-input">
                <label
                    for="password"
                    class="c-input__label"
                >
                    パスワード
                </label>
                <input
                    name="password"
                    id="password"
                    type="password"
                    class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> c-input__target"
                    value="<?php echo e(old('password')); ?>"
                    required
                />
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="l-alert__text--red"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </li>
            <li class="c-list c-input">
                <label
                    for="confirm"
                    class="c-input__label"
                >
                    確認用パスワード
                </label>
                <input
                    name="password_confirmation"
                    id="password_confirmation"
                    type="password"
                    class="<?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> c-input__target"
                    value="<?php echo e(old('password_confirmation')); ?>"
                    required
                />
                <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="l-alert__text--red"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </li>
            <?php if(Request::is('register-user')): ?>
            <li class="c-list c-input u-ml10">
                <div class="c-input__checkbox u-mb10">
                    <label for="man">
                        <span>男性</span>
                        <input
                            id="man"
                            name="sex"
                            type="radio"
                            value="man"
                            checked
                        >
                        <div class="color-box circle"></div>
                    </label>
                </div>
                <div class="c-input__checkbox">
                    <label for="woman">
                        <span>女性</span>
                        <input
                            id="woman"
                            name="sex"
                            type="radio"
                            value="woman"
                        >
                        <div class="color-box circle"></div>
                    </label>
                </div>
            </li>
            <?php elseif(Request::is('register-shop')): ?>
            <li class="c-list c-input">
                <label
                    for="tel"
                    class="c-input__label"
                >
                    ショップ電話番号
                </label>
                <input
                    name="tel"
                    id="tel"
                    type="tel"
                    class="<?php $__errorArgs = ['tel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> c-input__target"
                    value="<?php echo e(old('tel')); ?>"
                    required
                />
                <?php $__errorArgs = ['tel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="l-alert__text--red"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </li>
            <li class="c-list c-input">
                <label
                    for="url"
                    class="c-input__label"
                >
                    ショップURL
                </label>
                <input
                    name="url"
                    id="url"
                    type="url"
                    class="<?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> c-input__target"
                    value="<?php echo e(old('url')); ?>"
                />
                <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="l-alert__text--red"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </li>
            <li class="c-list c-input">
                <label
                    for="detail"
                    class="c-input__label"
                >ショップ詳細</label>
                <textarea
                    name="detail"
                    id="detail"
                    class="<?php $__errorArgs = ['detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> c-input__target"
                ><?php echo e(old('detail')); ?></textarea>
                <?php $__errorArgs = ['detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="l-alert__text--red"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </li>
            <li class="c-list c-input">
                <label
                    for="hour"
                    class="c-input__label"
                >営業時間・休日</label>
                <textarea
                    name="hour"
                    id="hour"
                    class="<?php $__errorArgs = ['hour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> c-input__target"
                ><?php echo e(old('hour')); ?></textarea>
                <?php $__errorArgs = ['hour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="l-alert__text--red"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </li>
            <li class="c-list">
                <div id="categoryList"></div>
            </li>
            <?php endif; ?>
            <li class="c-list c-button">
                <button
                    type="submit"
                    class="c-button__target--contained c-button--long"
                >
                    仮登録
                </button>
            </li>
        </ul>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\React\2021_07_06_laravel\motasapo\backend\resources\views/auth/register.blade.php ENDPATH**/ ?>