<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\work\React\2021_07_06_laravel\motasapo\backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>