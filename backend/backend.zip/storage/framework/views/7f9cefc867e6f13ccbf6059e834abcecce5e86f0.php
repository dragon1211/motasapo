

<?php $__env->startSection('title', '利用規約'); ?>
<?php $__env->startSection('description', '利用規約のページです。バイク・車好きのためのウェブアプリ「モタサポ」の公式アプリです。'); ?>
<?php $__env->startSection('pageCss'); ?>
<?php $__env->startSection('h1', '利用規約'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-text page-content">
    <h2>利用規約</h2>
    <ol>
        <li>利用規約</li>
        <li>利用規約</li>
        <ol>
            <li>利用規約</li>
            <li>利用規約</li>
        </ol>
        <li>利用規約</li>
        <li>利用規約</li>
        <li>利用規約</li>
        <li>利用規約</li>
    </ol>
    <h2>利用規約</h2>
    <p>利用規約利用規約利用規約利用規約利用規約利用規約利用規約利用規約利用規約利用規約利用規約利用規約</p>
    <ol>
        <li>利用規約</li>
        <li>利用規約
            <ol>
                <li>利用規約</li>
                <li>利用規約
                    <ol>
                        <li>利用規約</li>
                        <li>利用規約</li>
                    </ol>
                </li>
            </ol>
        </li>
        <li>利用規約</li>
        <li>利用規約
            <ol>
                <li>利用規約</li>
                <li>利用規約
                    <ol>
                        <li>利用規約</li>
                        <li>利用規約</li>
                    </ol>
                </li>
            </ol>
        </li>
        <li>利用規約</li>
        <li>利用規約</li>
    </ul>
    <h2>利用規約</h2>
    <ol>
        <li>利用規約</li>
        <li>利用規約
            <ol>
                <li>利用規約</li>
                <li>利用規約
                    <ol>
                        <li>利用規約</li>
                        <li>利用規約</li>
                    </ol>
                </li>
            </ol>
        </li>
        <li>利用規約</li>
        <li>利用規約
            <ol>
                <li>利用規約</li>
                <li>利用規約
                    <ol>
                        <li>利用規約</li>
                        <li>利用規約</li>
                    </ol>
                </li>
            </ol>
        </li>
        <li>利用規約</li>
        <li>利用規約</li>
    </ol>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\React\2021_07_06_laravel\motasapo\backend\resources\views/pages/terms.blade.php ENDPATH**/ ?>