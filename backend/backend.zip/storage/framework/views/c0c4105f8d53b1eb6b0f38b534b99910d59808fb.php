

<?php $__env->startSection('title', 'バイク・車好きのためのウェブアプリ'); ?>
<?php $__env->startSection('description', 'バイク・車好きのためのウェブアプリ「モタサポ」の公式アプリです。'); ?>
<?php $__env->startSection('pageCss'); ?>
<?php $__env->startSection('h1', 'モタサポ'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-screen">
    <img src="<?php echo e(asset('/storage/base/top-screen.png')); ?>" alt="車・バイクの画像">
</div>
<div class="page-content">
    <ul class="c-lists">
        <li class="c-list c-button">
            <a class="c-button__target--contained c-button--long" href="<?php echo e(route(('register.user'))); ?>">ユーザー登録（無料）</a>
        </li>
        <li class="c-list c-button">
            <a class="c-button__target--contained c-button--long" href="<?php echo e(route(('register.shop'))); ?>">ショップ登録（有料）</a>
        </li>
        <li class="c-list c-button">
            <a class="c-button__target--outlined c-button--long" href="<?php echo e(route('login')); ?>">ログイン</a>
        </li>
        <li class="c-list c-button">
            <a class="c-button__target--text" href="<?php echo e(route('password.request')); ?>">パスワードを忘れた方</a>
        </li>
    </ul>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\React\2021_07_06_laravel\motasapo\backend\resources\views/pages/top.blade.php ENDPATH**/ ?>