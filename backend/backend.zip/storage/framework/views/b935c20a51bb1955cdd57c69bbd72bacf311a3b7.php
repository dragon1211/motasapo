<?php $__env->startSection('header'); ?>
<header class="l-header">
    <div class="wrap">
        <div class="l-header--inner c-flex v-center h-between">
            <div class="l-header--logo u-w70">
                <a href="<?php echo e(route('page.top')); ?>">
                    <img src="<?php echo e(asset('/storage/base/logo-square.png')); ?>" alt="モタサポのロゴ">
                </a>
            </div>
            <div class="l-header--title">
                <h1><?php echo $__env->yieldContent('h1'); ?></h1>
            </div>
            <div class="l-header--nav u-w70 c-flex h-between">
                <div class="hamburger-memu nav-icon">
                    <a href="">
                        <span class="batch-circle"></span>
                        <img src="<?php echo e(asset('/storage/base/icon-header-comment-g.png')); ?>" alt="メッセージアイコン">
                    </a>
                </div>
                <div class="hamburger-memu nav-icon">
                    <a href="">
                        <span class="batch-circle"></span>
                        <img src="<?php echo e(asset('/storage/base/icon-header-mail-g.png')); ?>" alt="メールアイコン">
                    </a>
                </div>
            </div>
        </div>
    </div>
</header>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\work\React\2021_07_06_laravel\motasapo\backend\resources\views/layouts/header-account.blade.php ENDPATH**/ ?>