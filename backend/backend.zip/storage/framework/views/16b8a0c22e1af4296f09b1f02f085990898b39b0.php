<?php $__env->startSection('footer'); ?>
<footer class="l-footer wrap">
    <p>© ZOTMAN INC. ALL RIGHTS RESERVED.</p>
</footer>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\work\React\2021_07_06_laravel\motasapo\backend\resources\views/layouts/footer.blade.php ENDPATH**/ ?>