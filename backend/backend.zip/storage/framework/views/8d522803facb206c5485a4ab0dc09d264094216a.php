<?php echo e($slot); ?>

<?php /**PATH D:\work\React\2021_07_06_laravel\motasapo\backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>