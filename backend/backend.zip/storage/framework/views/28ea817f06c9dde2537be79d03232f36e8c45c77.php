


<?php $__env->startSection('title', 'ログイン'); ?>
<?php $__env->startSection('description', 'お問い合わせページです。バイク・車好きのためのウェブアプリ「モタサポ」の公式アプリです。'); ?>
<?php $__env->startSection('pageCss'); ?>
<?php $__env->startSection('h1', 'ログイン'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('js/components/InputAnimation.js')); ?>"></script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-headline page-content">
    <p>ログイン情報を<br>入力してください。</p>
</div>
<div class="page-content">
    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <ul class="c-lists">
            <li class="c-list c-input">
                <label
                    for="email"
                    class="c-input__label"
                >
                    メールアドレス
                </label>
                <input
                    name="email"
                    id="email"
                    type="email"
                    class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> c-input__target"
                    value="<?php echo e(old('email')); ?>"
                    required
                    autofocus
                />
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="l-alert__text--red"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </li>
            <li class="c-list c-input">
                <label
                    for="email"
                    class="c-input__label"
                >
                    パスワード
                </label>
                <input
                    name="password"
                    id="password"
                    type="password"
                    class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> c-input__target"
                    value="<?php echo e(old('password')); ?>"
                    required
                    autofocus
                />
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="l-alert__text--red"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </li>
            <li class="c-list c-input u-ml10">
                <div class="c-input__checkbox">
                    <label for="remember_me">
                        <span>ログイン情報を保持する</span>
                        <input
                            id="remember_me"
                            name="remember"
                            type="checkbox"
                            value="remember"
                        >
                        <div class="color-box"></div>
                    </label>
                </div>
            </li>
            <li class="c-list c-button">
                <button
                    type="submit"
                    class="c-button__target--contained c-button--long"
                >
                    ログイン
                </button>
            </li>
        </ul>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\React\2021_07_06_laravel\motasapo\backend\resources\views/auth/login.blade.php ENDPATH**/ ?>