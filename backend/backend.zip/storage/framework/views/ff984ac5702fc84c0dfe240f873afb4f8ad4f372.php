

<?php $__env->startSection('title', '投稿一覧'); ?>
<?php $__env->startSection('pageCss'); ?>
<?php $__env->startSection('h1', '投稿一覧'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('js/components/InputAnimation.js')); ?>"></script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.header-account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div id="account"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\React\2021_07_06_laravel\motasapo\backend\resources\views/accounts/index.blade.php ENDPATH**/ ?>