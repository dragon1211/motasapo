// JS file
require('./bootstrap');
require('alpinejs');

// React file
// require('./../tsx/components/CategoryLists.tsx');
