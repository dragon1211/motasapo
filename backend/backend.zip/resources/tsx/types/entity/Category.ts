// typescript設定
export type Category = {
    id: string;
    name: string;
    created_at: Date;
    updated_at: Date;
};
