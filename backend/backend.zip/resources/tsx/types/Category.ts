// typescript設定
export type Category = {
    id: string;
    // id: number;
    name: string;
    created_at: Date;
    updated_at: Date;
};
