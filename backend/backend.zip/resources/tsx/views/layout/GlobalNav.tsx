import React from 'react';
// 投稿
import Post from '../pages/accounts/posts/index';
import Search from '../pages/accounts/search/index';
import Detail from '../pages/accounts/detail/index';
import GeoLocation from '../pages/accounts/gps/index';
import 'bootstrap/dist/css/bootstrap.min.css';
// 検索ページ
// 新規投稿ページ
// GPSページ
// マイページ
import { FaSearch, FaHome, FaCameraRetro } from "react-icons/fa";
import { IoLocation } from "react-icons/io5";
import './layout.css'
import {
  BrowserRouter,
  Switch,
  Route,
  Link
} from "react-router-dom";

export default function GlobalNav() {
  return (
    <BrowserRouter>
      <Switch>
        <Route path="/account/post/">
          <Post />
        </Route>
        <Route path="/account/search/">
          <Search />
        </Route>
        <Route path="/account/profile/:id/post/">
          <Detail />
        </Route>
        <Route path="/account/new-post/">
          <NewPost />
        </Route>
        <Route path="/account/gps/">
          <GeoLocation />
        </Route>
        <Route path="/account/mypage/">
          <Mypage />
        </Route>
      </Switch>
      <div className="row mx-auto px-auto pt-3">
        <div className="col-md-1 col-sm-1"></div>
        <div className="col-md-2 col-sm-2">
          <div className="text-center">
            <Link to="/account/post/" className="l-nav--link link-house">
              <FaHome className="icon-layout" />
            </Link>
          </div>
        </div>
        <div className="col-md-2 col-sm-2">
          <div className="text-center">
            <Link to="/account/search/" className="l-nav--link link-search">
              <FaSearch className="icon-layout" />
            </Link>
          </div>
        </div>
        <div className="col-md-2 col-sm-2">
          <div className="text-center">
            <Link to="/account/new-post/" className="l-nav--link link-camera">
              <FaCameraRetro className="icon-layout" />
            </Link>
          </div>
        </div>
        <div className="col-md-2 col-sm-2">
          <div className="text-center">
            <Link to="/account/gps/" className="l-nav--link link-map">
              <IoLocation className="icon-layout" />
            </Link>
          </div>
        </div>
        <div className="col-md-2 col-sm-2">
          <div className="text-center">
            <Link to="/account/mypage/" className="l-nav--link link-icon">
              <img src="/storage/base/50000087_1193305484150794_571276761136889856_n.jpeg" alt="" className="image-icon-layout" />
            </Link>
          </div>
        </div>
        <div className="col-md-1 col-sm-1"></div>
      </div>
    </BrowserRouter>
  );
}


function NewPost() {
  return <h2>NewPost</h2>;
}
function Gps() {
  return <h2>Gps</h2>;
}
function Mypage() {
  return <h2>MyPage</h2>;
}



{/* <div className="l-nav">
        <div className="l-nav--items c-flex v-center h-between">
          <div className="l-nav--item is-selected">
            <Link to="/account/post/" className="l-nav--link link-house">
              <span />
            </Link>
          </div>
          <div className="l-nav--item">
            <Link to="/account/search/" className="l-nav--link link-search">
              <span />
            </Link>
          </div>
          <div className="l-nav--item">
            <Link to="/account/new-post/" className="l-nav--link link-camera">
              <span />
            </Link>
          </div>
          <div className="l-nav--item">
            <Link to="/account/gps/" className="l-nav--link link-map">
              <span />
            </Link>
          </div>
          <div className="l-nav--item">
            <Link to="/account/mypage/" className="l-nav--link link-icon">
              <span>
                <img src="/storage/base/50000087_1193305484150794_571276761136889856_n.jpeg" alt="" />
              </span>
            </Link>
          </div>
        </div>
      </div> */}