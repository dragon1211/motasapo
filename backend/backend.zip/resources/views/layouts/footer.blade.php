@section('footer')
<footer class="l-footer wrap">
    <p>© ZOTMAN INC. ALL RIGHTS RESERVED.</p>
</footer>
@endsection
