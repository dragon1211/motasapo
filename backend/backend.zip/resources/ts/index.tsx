import React from 'react';
import ReactDOM from 'react-dom';
// import App from './App';


const App = () => {
    return(
        <h1>indexだよ</h1>
    )
}

ReactDOM.render(
    <App />,
    document.getElementById('app')
)
